function validateContactForm() {
    const name = document.forms["Userinfo"]["name"].value;
    const email = document.forms["Userinfo"]["email"].value;
    if (name == "" || email == "") {
      alert("Name and email must be filled out.");
      return false;
    }
  }
  function validateContractForm() {
    const fullName = document.forms["contractForm"]["Name"].value;
    const service = document.forms["contractForm"]["service"].value;
    if (fullName == "" || service == "") {
      alert("Please provide your full name and select a service.");
      return false;
    }
  }
  function validateFeedbackForm() {
    const feedback = document.forms["feedbackForm"]["feedback"].value;
    if (feedback == "") {
      alert("Please provide your feedback.");
      return false;
    }
  }
  function filterProjects(type) {
    const projects = document.querySelectorAll('.project');
    projects.forEach(project => {
      project.style.display = project.dataset.type === type || type === 'all' ? 'block' : 'none';
    });
  }